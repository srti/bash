# coding: utf-8
'''
DROP INDEX

Removes an existing index. The default index name is `table_name_column_name_idx`.

Synopsis


DROP INDEX [ IF EXISTS ] [keyspace_name.]index_name ;



'''
